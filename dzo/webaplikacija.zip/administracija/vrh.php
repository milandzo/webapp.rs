<?php
define("BASE_PATH",true);
include "../konekcija.php";
?>
<div id="telo">

<div id="vrh">
<img src="../slike/vesti.jpg" width="100%" height="200px"/>
</div>
<div id="meni">
<a href="administraija/panel.php">Administracija</a><a href="../vesti.php">Vesti</a>
</div>
</div>
<center>
<div id="prikaz">
<h2>Dodavanje sa administracionog panela</h2>
<div id="dodajvesti">
<a href="dodajvesti.php">Dodaj vesti</a><br/>
<a href="dodajkorsnika.php">Dodaj korisnika</a><br/>
<a href="dodavanjekomentara.php">Dodavanje komentara</a><br/>


<?php
$query="select * from vesti LIMIT 1";
$prikaz=$konekcija->query($query);
foreach($prikaz as $data){
  echo "<h2>Prikaz vesti<h2>";
  echo $data['naslov']."<br/>";
  echo $data['vesti']."<br/>";
echo "<a href='../dodajkomentar.php'>Dodaj komentar</a>";
}
$query1="select * from komentar LIMIT 1";
$prikaz1=$konekcija->query($query1);
foreach($prikaz1 as $data1){
  echo "<h2>Prikaz komentara<h2>";
  echo $data1['korisnik']."<br/>";
  echo $data1['komentar']."<br/>";
echo "<a href='../dodajkomentar.php'>Dodaj komentar</a>";
}
?>
</div>
</center>