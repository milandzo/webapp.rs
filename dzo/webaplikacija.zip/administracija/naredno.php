<?php
session_start();
header("Location:panel.php");

?>